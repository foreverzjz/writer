<?php
header ( "content-type:text/html;charset=utf-8" );
include "model.class.php";
@$model =new Model("content");
@mysql_query("set names 'utf8'");

include "simpleDict.php";
if(file_exists("E://sensitive.txt")){}
else{
	SimpleDict::make("SensitiveWord.txt", "E://sensitive.txt");
}
$dict = new SimpleDict("E://sensitive.txt");
?>
<?php
if ((($_FILES["file"]["type"] == "text/plain"))){
	if ($_FILES["file"]["error"] > 0){
		echo "Error: " . $_FILES["file"]["error"] . "<br />";
    }else{
		$fp = fopen($_FILES["file"]["tmp_name"], 'r');
		//while (!feof($fp)) {
			//$line = fgets($fp);
			//$u=explode('# ', $line);//如果有分割
			//mysql_query("INSERT INTO `user` (title)VALUES('trim($line)')",$conn); 
			//$model->insert(array('content'=>$line));
		//}
		$content = fread($fp,$_FILES["file"]["size"]);
		fclose($fp);  
		//$content = addslashes($content);
		$replaced = $dict->replace($content, "");
		if(strlen($content)>strlen($replaced)){
			echo "已将敏感词过滤后存储！";
		}else{
			echo "已存储！";
		}
		$model->insert(array('content'=>$replaced));
    }
	if (file_exists("upload/" . $_FILES["file"]["name"])){
		echo $_FILES["file"]["name"] . " already exists. ";
    }else{
		move_uploaded_file($_FILES["file"]["tmp_name"],
		"e://upload//" . $_FILES["file"]["name"]);
		echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
    }
}else{
	echo "Invalid file";
}

?>